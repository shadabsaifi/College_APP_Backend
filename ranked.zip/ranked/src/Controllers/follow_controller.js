import commFunc from '../Modules/commonFunction';
import responses from '../Modules/responses';
import constant from '../Modules/constant';
import connection from '../Modules/connection.js';
import followModel from '../Modals/follow_model';
import config from '../config/development';
import md5 from 'md5';
import _ from 'lodash';
import async from 'async';

let arr = [];

exports.send_request = (req, res) => {
	let { reciever_id, device_type, device_token } =req.body ;

	let user_id = req.user.user_id ;

	let manKeys = ["reciever_id", "device_type", "device_token"];

	let manValues = {reciever_id, device_type, device_token};
	let current_date = new Date();
	let created_on = Math.round(current_date.getTime() / 1000);
	let request_id =  md5(new Date());
	let request_status = 0 ;
	console.log( md5(new Date()));
	console.log(request_id);

	let values = {reciever_id, request_id , request_status, user_id,created_on};
	let condition ={user_id, reciever_id};

	commFunc.checkKeyExist(manValues, manKeys)
	.then(result => {
		if(result.length) {
			responses.parameterMissing(res,result[0])
		} else {
			followModel.selectQuery(condition)
			.then((results) => {
				if(results.length) {
					responses.invalidCredential(res, constant.responseMessages.REQUEST_ALREADY_SENT);
				} else {
					followModel.insertQuery(values)
					.then((followResults) => {
						//***********code for push notification**********************//
						responses.success(res, followResults[0]);
					}).catch((error) => responses.sendError(error.message, res));
				}
			}).catch((error) => responses.sendError(error.message, res));
		}
	}).catch((error) => responses.sendError(error.message, res));
};

exports.show_request = (req, res) => {
	let reciever_id = req.user.user_id;
	let condition = {"reciever_id" : reciever_id, "request_status" : 0 };

	followModel.selectQuery2(condition)
	.then((userResult) =>{
		console.log("::::::::::::::::::::::::");
		console.log(userResult);
		console.log("::::::::::::::::::::::::");
		async.eachSeries(userResult, get_user_details, (results) => { 
			responses.success(res, arr);
			arr = [];
		})
		function get_user_details(userResult, callback) {
			async.parallel([
		        function(callback) {
		            get_user_result(userResult, function(total_user_result){
		                callback(null,total_user_result)
		            });
		        }
		    ],function(err, results) {
		    	userResult.total_user_result = results[0];
		    	arr.push(userResult);
            	callback();
			})
			function get_user_result(userResult, callback) {
				let user_id = userResult.user_id;
				let sql = "SELECT * FROM `tb_user` where `user_id` = ? ";
				connection.query(sql, [user_id], (err, result) =>{
					if(err) {
						callback(0);
					} else {
						callback(result[0]);
					}
				})
			}
		}

	}).catch((error) => responses.sendError(error.message, res));
};

 exports.accept_request =(req, res) => {
 	let reciever_id = req.user.user_id;
 	let {user_id, request_status, request_id} = req.body; 
 	let updateData = {request_status};
 	let condition ={request_id};
 	let manKeys = ["user_id" , "request_status"];
 	let manValues = {user_id, request_status};

	commFunc.checkKeyExist(manValues, manKeys)
 	.then((result) => {
		if(result.length) {
			responses.parameterMissing(res,result[0]);
		} else {
			followModel.updateQuery(updateData, condition)
			.then((updateResult) => {
				console.log(updateResult);
				if(request_status == 1) {
					let follower_id = updateResult.user_id;
					let user_id = updateResult.reciever_id;
					let follow_id  = md5(new Date());
					let current_date = new Date();
					let is_follow = 1;
					let created_on = Math.round(current_date.getTime() / 1000);
					let insertData = {follow_id, follower_id, user_id, follow_id, created_on};
					followModel.insertQuery2(insertData)
					.then((Results) => {
						//***************** code for push notification ****************//
						responses.success(res, Results[0]);
					}).catch((error) => responses.sendError(error.message, res));
				} else if(request_status == 2){
					responses.success(res, updateResult[0]);
				}

			}).catch((error) => responses.sendError(error.message, res));
		}
	}).catch((error) => responses.sendError(error.message, res));

 };

 exports.show_user = (req, res) => {

 	let user_id = req.user.user_id;
 	let {college_name} = req.body;
 	// user_id = {"user_id" : user_id};
 	// let {college_name} = req.body;
 	// college_name = {"college_name" : college_name};
 	// college_name = {"college_name" : college_name};
 	let manKeys = ["college_name"];
 	let manValues = {college_name};

 	console.log(user_id, college_name);

 	commFunc.checkKeyExist(manValues,manKeys)
 	.then((result) => {
 		followModel.selectQuery3({college_name, user_id})
 		.then((userResult) => {
 			responses.success(res, userResult);
 		}).catch((error) => responses.sendError(error.message, res));			
 		
 	}).catch((error) => responses.sendError(error.message, res)); 
 };


 exports.show_friends = (req, res) => {
 	let user_id = req.user.user_id;
 	let condition = {user_id};
 	console.log(condition);
 	followModel.selectQuery4(condition)
 	.then((friendResult) => {
 		console.log(":::::::::::::::::::::::");
 		console.log(friendResult);
 		console.log(":::::::::::::::::::::::");
 		async.eachSeries(friendResult, get_user_details, (results) => {
			responses.success(res, arr);
			arr = [];
		})
	 	function get_user_details(userResult, callback) {
	 		console.log(userResult);
	 		console.log("INSIDE get_user_details");
	 		console.log(userResult.user_id == user_id);
	 		console.log(userResult.follower_id == user_id);
	 		console.log("::::::::::::::::::::::::::::::::::");
	 		if(userResult.follower_id == user_id) {
	 			console.log("1");
	 			user_id = userResult.user_id ;	
	 		} else {
	 			user_id = userResult.follower_id;
	 		}	
			// let user_id = userResult.follower_id ;
			let sql = "SELECT * FROM `tb_user` where `user_id` = ? ";
			connection.query(sql, [user_id], (err, result) =>{
				if(err) {
					callback(0);
				} else {
					arr.push(result[0]);
					callback();
				}
			})
		}
 	}).catch((error) => responses.sendError(error.message, res));
 }

